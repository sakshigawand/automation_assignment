package StepDefinations;

import java.util.concurrent.TimeUnit;

 

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

 

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class topmenu {

	    WebDriver driver;
	    @Given("User is on Homepage for top menu on site")
	    public void user_is_on_homepage_for_top_menu_on_site() throws InterruptedException {
	        System.setProperty("webdriver.chrome.driver","C:/Users/sagawand/eclipse-workspace/demoA/PracticeAutomation/src/test/resources/Drivers/chromedriver.exe");
	        driver = new ChromeDriver();
	        driver.navigate().to("https://flipkart.com/");
	        driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	        Thread.sleep(3000);
	        driver.findElement(By.xpath("/html/body/div[2]/div/div/button")).click();

	    }

	 

	    @Then("user should see top menu")
	    public void user_should_see_top_menu() {
	       driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[2]/div")).isEnabled();
	    }

	 

//	    @Then("user redirect to homepage top menu")
//	    public void user_redirect_to_homepage_top_menu() {
//	      
//	    }

	 

	    @When("I move cursor on Electronics tab")
	    public void I_move_cursor_on_electronics_tab() {
	        driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[2]/div/div/div[4]/a/div[1]")).click();
	        driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	        System.out.println("Electronics Done");
	    }

	 

	    @When("I move cursor on Grocery tab")
	    public void I_move_cursor_on_Grocery_tab() {
	        driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[2]/div/div/div[1]/a/div[2]")).click();
	        driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	        System.out.println("Grocery Done");
	    }

	 

	    

	 

	    @When("I move cursor on Mobile tab")
	    public void I_move_cursor_on_mobile_tab() {
	        driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[2]/div/div/div[2]/a/div[2]")).click();
	        driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	        System.out.println("Mobile Done");
	    }

	 

	    

	 

	    @When("I move cursor on Fashion tab")
	    public void I_move_cursor_on_fashion_tab() {
	        driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[2]/div/div/div[3]/a/div[2]/div/div")).click();
	        driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	        System.out.println("Fashion Done");
	    }

	 

	    

	 

	    @When("I move cursor on Home tab")
	    public void I_move_cursor_on_home_tab() {
	        driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[2]/div/div/div[5]/a/div[2]/div/div")).click();
	        driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	        System.out.println("Home Done");
	    }

	 

	    

	 

	    @When("I move cursor on Travel tab")
	    public void I_move_cursor_on_travel_tab() {
	        driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[2]/div/div/div[7]/a/div[2]")).click();
	        driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	        System.out.println("Travel Done");
	    }

}

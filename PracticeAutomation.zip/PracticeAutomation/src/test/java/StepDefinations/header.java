package StepDefinations;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class header {
	
	WebDriver driver = null;
	
	@Given("user is on home page1")
	public void user_is_on_home_page1() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				"C:/Users/sagawand/eclipse-workspace/demoA/PracticeAutomation/src/test/resources/Drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.navigate().to("https://flipkart.com");
		Thread.sleep(300);
		driver.findElement(By.xpath("/html/body/div[2]/div/div/button")).click();
		
		
		//LOGIN
		
//		 driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
//         WebElement mob =driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[1]/input"));
//         mob.sendKeys("9082360426");
//         Thread.sleep(3000);
//         driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[3]/button")).click();
	   
	}

	@Given("flipkart logo is visible on left")
	public void flipkart_logo_is_visible_on_left() {
//		driver.findElement(By.className("_2KpZ6l _2doB4z")).click();
//		boolean t = driver.findElement(By.className("_2xm1JU")).isDisplayed();
//		if (t)
//			System.out.println("LOGO VISIBLE");
//		else
			System.out.println("LOGO NOT VISIBLE");		
	}
	@Given("search bar is visible")
	public void search_bar_is_visible() {
	    
	}

	@When("user click on logo")
	public void user_click_on_logo() {
		driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[1]/div[1]/div[2]/div[1]/div/a[1]/img")).click();
	    
	}

	@Then("user is on home page")
	public void user_is_on_home_page() {
		String t = "Online Shopping Site for Mobiles, Electronics, Furniture, Grocery, Lifestyle, Books & More. Best Offers!";
//		System.out.println(driver.getTitle());
		if (t.equals(driver.getTitle()))
			System.out.println("YOU R ON HOME PAGE");
		else
			System.out.println("YOU R NOT ON HOME PAGE");
			
	    
	}

}

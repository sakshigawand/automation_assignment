package StepDefinations;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class cart {	
	 WebDriver driver;
	    @Given("user on flipkart cart page")
	    public void user_on_flipkart_cart_page() throws InterruptedException {
	         System.setProperty("webdriver.chrome.driver","C:/Users/sagawand/eclipse-workspace/demoA/PracticeAutomation/src/test/resources/Drivers/chromedriver.exe");
	            driver = new ChromeDriver();
	            driver.navigate().to("https://flipkart.com/");
	            driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	            Thread.sleep(3000);
	            driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	            WebElement mob =driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[1]/input"));
	            mob.sendKeys("7972981370");
	          //  Thread.sleep(3000);
	            driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[3]/button")).click();

	    }

	 

	    @When("user click on cart")
	    public void user_click_on_cart() {
	        //new WebDriverWait(getWebDriver(), 10).until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class=\"_1psGvi\"]"))).click();

	        WebDriverWait wait = new WebDriverWait(driver, 10);
	        driver.findElement(By.xpath("//button[@class=\"_2KpZ6l _2doB4z\"]")).click();
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\\\"container\\\"]/div/div[1]/div[1]/div[2]/div[6]/div/div/a"))).click();
////	        driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[1]/div[1]/div[2]/div[6]/div/div/a")).click();
////	        driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	            driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[2]/div/div/div/div/div[2]/div/div[1]")).isDisplayed();    }
//	    @And("user gets empty cart")
//	    public void user_gets_empty_cart() {
//	       driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[2]/div/div/div/div/div[2]/div/div[1]")).isDisplayed();
//	    }

	    @Then("user gets start shopping")
	    public void user_gets_start_shopping() {
	     driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[2]/div/div/div/div/div[2]/div/button")).click();
	    }
}

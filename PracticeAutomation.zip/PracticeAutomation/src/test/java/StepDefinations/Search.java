package StepDefinations;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Search {
	
	 WebDriver driver;
	    @Given("User is on the hompage")
	    public void user_is_on_the_hompage() throws InterruptedException {
	         System.setProperty("webdriver.chrome.driver","C:/Users/sagawand/eclipse-workspace/demoA/PracticeAutomation/src/test/resources/Drivers/chromedriver.exe");
	            driver = new ChromeDriver();
	            driver.navigate().to("https://flipkart.com/");
	            driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	            Thread.sleep(3000);
	            }

	    @When("user click on searchbar")
	    public void user_click_on_searchbar() {
	        driver.findElement(By.xpath("//button[@class=\"_2KpZ6l _2doB4z\"]")).click();
	        WebElement searchh= driver.findElement(By.xpath("//input[@class=\"_3704LK\"]"));
	        searchh.sendKeys("mobile");
	    }

	    @Then("user will get popular result")
	    public void user_will_get_popular_result() {

	    }

	 

	    @When("user writes on searchbar")
	    public void user_writes_on_searchbar() {
	        // Write code here that turns the phrase above into concrete actions

	    }

	 

	    @And("user press search button")
	    public void user_press_search_button() {
	        // Write code here that turns the phrase above into concrete actions

	    }

	 

	    @Then("user will get search result")
	    public void user_will_get_search_result() {

	    }


}

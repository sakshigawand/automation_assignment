//package pages;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//
//public class loginPage {
//	
//	By Mobile_number = By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[1]/input");
//	By password = By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[2]/input");
//	By btn_login = By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[4]/button");
//	 WebDriver driver;
//	
////	 constructor for driver
//	public loginPage(WebDriver driver) {
//		this.driver = driver ;
//	}
//	
//	public void enter_number(String num) {
//		driver.findElement(Mobile_number).sendKeys(num);
//	}
//	
//	public void password(String pass) {
//		driver.findElement(password).sendKeys(pass);
//	}
//	
//	public void clk_login() {
//		driver.findElement(btn_login).click();
//	}
//	
//
//}
